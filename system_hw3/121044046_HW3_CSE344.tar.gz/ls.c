//
// Created by siyahas on 25.04.2018.
//


#include <stdio.h>

int main(int argc, char *argv[]){

}